"""Context management strategies."""
